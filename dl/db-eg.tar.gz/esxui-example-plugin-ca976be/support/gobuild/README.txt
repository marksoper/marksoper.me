This directory contains files necessary for GoBuild support. See
https://wiki.eng.vmware.com/GoBuild for details.
